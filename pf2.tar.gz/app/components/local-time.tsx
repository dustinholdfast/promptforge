"use client";

import { useEffect, useState } from "react";

/**
 * Timestamps are the classic hydration mismatch: the server formats in its own
 * locale and timezone, the browser formats in yours, and React complains that
 * the HTML differs. So render a stable, unambiguous string on the server and
 * upgrade to the reader's local format once mounted.
 */
export function LocalTime({ value }: { value: string }) {
  const iso = toIso(value);
  const [local, setLocal] = useState<string | null>(null);

  useEffect(() => {
    setLocal(new Date(iso).toLocaleString());
  }, [iso]);

  return (
    <time dateTime={iso} suppressHydrationWarning>
      {local ?? iso.slice(0, 16).replace("T", " ") + " UTC"}
    </time>
  );
}

/**
 * SQLite's CURRENT_TIMESTAMP writes "2026-08-14 10:29:18" — UTC, but with no
 * timezone marker, which `new Date()` then reads as *local* time and silently
 * shifts by your offset. Normalise it to a real ISO instant.
 */
export function toIso(value: string): string {
  if (!value) return new Date(0).toISOString();
  if (/(Z|[+-]\d{2}:?\d{2})$/.test(value)) return new Date(value).toISOString();
  const sqlite = /^(\d{4}-\d{2}-\d{2})[ T](\d{2}:\d{2}:\d{2})/.exec(value);
  if (sqlite) return `${sqlite[1]}T${sqlite[2]}Z`;
  const parsed = new Date(value);
  return Number.isNaN(parsed.getTime()) ? new Date(0).toISOString() : parsed.toISOString();
}
