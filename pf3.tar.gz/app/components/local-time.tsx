"use client";

import { useEffect, useState } from "react";
import { toIso } from "../../lib/time";

/**
 * Timestamps are the classic hydration mismatch: the server formats in its own
 * locale and timezone, the browser formats in yours, and React reports that the
 * HTML differs. Render a stable, unambiguous string on the server and upgrade
 * to the reader's local format once mounted.
 */
export function LocalTime({ value }: { value: string }) {
  const iso = toIso(value);
  const [local, setLocal] = useState<string | null>(null);

  useEffect(() => {
    setLocal(new Date(iso).toLocaleString());
  }, [iso]);

  return (
    <time dateTime={iso} suppressHydrationWarning>
      {local ?? `${iso.slice(0, 16).replace("T", " ")} UTC`}
    </time>
  );
}
